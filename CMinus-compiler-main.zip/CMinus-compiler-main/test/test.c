/*test.c*/
int main(){
	int a = 1, b = 2;
	if(a < b)
		a = b;
	return 0;
}